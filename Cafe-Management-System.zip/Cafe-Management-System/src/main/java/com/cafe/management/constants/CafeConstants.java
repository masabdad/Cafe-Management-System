package com.cafe.management.constants;

public class CafeConstants {

    public static final String SOMETHING_WENT_WRONG = "Something Went wrong";

    public static final String INVALID_DATA = "Invalid Data.";

    public static final String UNAUTHORIZED_ACCESS = "Unauthorized access.";

    public static final String STORE_LOCATION= "C:\\Masab dad";


    public static final String EMAIL_ALREADY_EXSIST = "Email Not Found";
}
